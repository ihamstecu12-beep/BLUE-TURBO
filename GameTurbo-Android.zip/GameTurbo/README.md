# Blue Turbo (proyek Android native, Kotlin)

1. Upload GameTurbo-Android.zip ke repo GitHub (nama file sama = menggantikan yang lama).
2. Build jalan otomatis (tab Actions). Download artifact GameTurbo-APK, ekstrak, instal app-debug.apk.
3. Buka Blue Turbo: intro video (Skip) -> dashboard. Ketuk FF/ML/PM/CD atau ikon menu kiri
   untuk membuka game. Pertama kali: aktifkan izin "Tampil di atas aplikasi lain".
   Untuk Jangan Ganggu / Anti Call: aktifkan izin "Akses Jangan Ganggu".

Catatan: angka "LAYAR" di panel = laju refresh layar, bukan FPS game lain.
