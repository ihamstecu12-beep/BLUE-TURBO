package com.example.gameturbo

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View

/** Tombol segi enam bergaya kaca. Label boleh dua baris (pisah dengan \n). */
class HexButton(ctx: Context, var icon: String, var label: String) : View(ctx) {
    var active = false
        set(v) {
            field = v
            invalidate()
        }
    var locked = false
        set(v) {
            field = v
            invalidate()
        }

    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.6f * d
    }
    private val ico = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val path = Path()

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension((66 * d).toInt(), (92 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val r = 27f * d
        val cy = r + 3f * d
        path.reset()
        for (i in 0 until 6) {
            val a = Math.toRadians(60.0 * i - 90)
            val x = cx + r * Math.cos(a).toFloat()
            val y = cy + r * Math.sin(a).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        fill.shader = if (active) {
            LinearGradient(0f, cy - r, 0f, cy + r, 0xB046D9FF.toInt(), 0xB07A6BFF.toInt(), Shader.TileMode.CLAMP)
        } else {
            LinearGradient(0f, cy - r, 0f, cy + r, 0x55FFFFFF, 0x14FFFFFF, Shader.TileMode.CLAMP)
        }
        stroke.color = if (locked) 0x40FFFFFF else 0xB0FFFFFF.toInt()
        c.drawPath(path, fill)
        c.drawPath(path, stroke)

        ico.textSize = 20f * d
        ico.color = 0xFFFFFFFF.toInt()
        c.drawText(if (locked) "🔒" else icon, cx, cy + 7f * d, ico)

        txt.textSize = 10.5f * d
        txt.color = if (locked) 0x80FFFFFF.toInt() else if (active) 0xFFFFFFFF.toInt() else 0xFFCFE2FF.toInt()
        val parts = label.split("\n")
        val base = if (parts.size == 1) 82f * d else 74f * d
        for (i in parts.indices) c.drawText(parts[i], cx, base + i * 12f * d, txt)
    }
}
