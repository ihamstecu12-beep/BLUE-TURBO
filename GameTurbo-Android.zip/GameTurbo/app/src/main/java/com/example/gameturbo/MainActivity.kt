package com.example.gameturbo

import android.animation.Keyframe
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast

/** Dashboard Blue Turbo. */
class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private val h = Handler(Looper.getMainLooper())
    private val sized = ArrayList<Pair<TextView, Float>>()
    private val glassList = ArrayList<Pair<View, Float>>()
    private val darkList = ArrayList<Pair<View, Float>>()

    private lateinit var stage: Pct
    private lateinit var snow: SnowView
    private lateinit var charView: ImageView
    private lateinit var bubbleBox: FrameLayout
    private lateinit var bubbleText: TextView
    private lateinit var nameView: TextView
    private lateinit var statView: TextView
    private lateinit var hiView: TextView
    private lateinit var avatar: ImageView
    private lateinit var tkIcon: ImageView
    private lateinit var dock: LinearLayout
    private lateinit var songTitle: TextView
    private lateinit var playBtn: TextView
    private lateinit var bar: BarView

    private val names = ArrayList<String>()
    private val uris = ArrayList<Uri?>()
    private var mp: MediaPlayer? = null
    private var cur = 0
    private var rep = false

    private var jellyOn = true
    private var chatOn = true
    private var chatIdx = 0
    private var typeRun: Runnable? = null
    private var hideRun: Runnable? = null
    private val lines = listOf(
        "Hii nama aku Shirayuki lu bisa panggil gw Yuki",
        "Gw temenin lu main game, fokus ya! 🎮",
        "Jangan lupa aktifin Jangan Ganggu biar nggak ada yang gangguin",
        "Ketuk gw lagi kalau mau ngobrol ✨"
    )

    private val games = listOf(
        Triple("FF", "Free Fire", listOf("com.dts.freefireth", "com.dts.freefiremax")),
        Triple("ML", "Mobile Legends", listOf("com.mobile.legends")),
        Triple("PM", "PUBG Mobile", listOf("com.tencent.ig", "com.pubg.imobile")),
        Triple("CD", "Call of Duty", listOf("com.activision.callofduty.shooter"))
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.immersive(window)
        prefs = getSharedPreferences("bt", MODE_PRIVATE)
        jellyOn = prefs.getBoolean("jelly", true)
        chatOn = prefs.getBoolean("chat", true)

        val root = FrameLayout(this)
        val bg = ImageView(this)
        bg.setImageResource(R.drawable.bg)
        bg.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))
        stage = Pct(this, true)
        root.addView(stage, FrameLayout.LayoutParams(-1, -1))
        snow = SnowView(this)
        snow.enabledSnow = prefs.getBoolean("snow", true)
        root.addView(snow, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        build()
        stage.onStage = { sw -> stage.post { applyStage(sw) } }
        initMusic()
        h.post(statRun)
    }

    override fun onResume() {
        super.onResume()
        Ui.immersive(window)
    }

    override fun onStop() {
        super.onStop()
        val m = mp
        if (m != null && m.isPlaying) {
            m.pause()
            playBtn.text = "▶"
        }
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        mp?.release()
        mp = null
        super.onDestroy()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_DOWN) snow.burst(ev.rawX, ev.rawY)
        return super.dispatchTouchEvent(ev)
    }

    // ---------- helper tampilan ----------
    private fun tv(text: String, f: Float, bold: Boolean = false, gravity: Int = Gravity.START or Gravity.CENTER_VERTICAL): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.gravity = gravity
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        sized.add(Pair(t, f))
        return t
    }

    private fun gl(v: View, f: Float): View {
        glassList.add(Pair(v, f))
        return v
    }

    private fun dk(v: View, f: Float): View {
        darkList.add(Pair(v, f))
        return v
    }

    private fun sq(w: Float): Float = w * 16f / 9f

    private fun round(iv: ImageView, frac: Float) {
        iv.clipToOutline = true
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, v.width * frac)
            }
        }
    }

    private fun logoView(frac: Float): ImageView {
        val i = ImageView(this)
        i.setImageResource(R.drawable.logo)
        i.scaleType = ImageView.ScaleType.CENTER_CROP
        round(i, frac)
        return i
    }

    private fun card(res: Int): FrameLayout {
        val f = FrameLayout(this)
        val pad = Ui.dp(this, 2.5f).toInt()
        f.setPadding(pad, pad, pad, pad)
        val bgd = GradientDrawable()
        bgd.setColor(0xE6FFFFFF.toInt())
        bgd.cornerRadius = Ui.dp(this, 12f)
        f.background = bgd
        val i = ImageView(this)
        i.setImageResource(res)
        i.scaleType = ImageView.ScaleType.CENTER_CROP
        i.clipToOutline = true
        val rad = Ui.dp(this, 9f)
        i.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, rad)
            }
        }
        f.addView(i, FrameLayout.LayoutParams(-1, -1))
        return f
    }

    // ---------- susunan dashboard ----------
    private fun build() {
        val s = stage
        s.add(gl(View(this), 3f), .06f, .09f, .88f, .74f)
        s.add(gl(View(this), 2.1f), .018f, .12f, .042f, .66f)

        val icons = listOf("＋", "⌕", "♫", "▶", "☾", "⚙", "ⓘ", "✦")
        for (i in icons.indices) {
            val t = tv(icons[i], 1.5f, gravity = Gravity.CENTER)
            gl(t, 5f)
            t.setOnClickListener { sideClick(i) }
            s.add(t, .0255f, .135f + i * .0815f, .027f, sq(.027f))
        }

        val clock = TextClock(this)
        clock.format24Hour = "HH:mm"
        clock.format12Hour = "HH:mm"
        clock.setTextColor(Color.WHITE)
        clock.typeface = Typeface.DEFAULT_BOLD
        clock.setShadowLayer(10f, 0f, 3f, 0x99081858.toInt())
        sized.add(Pair(clock, 5.2f))
        s.add(clock, .11f, .125f, .2f, .12f)
        val date = TextClock(this)
        date.format24Hour = "EEEE, dd/MM"
        date.format12Hour = "EEEE, dd/MM"
        date.setTextColor(Color.WHITE)
        date.setShadowLayer(6f, 0f, 1f, 0xB0081858.toInt())
        sized.add(Pair(date, 1.2f))
        s.add(date, .11f, .245f, .2f, .04f)

        s.add(CalView(this), .106f, .31f, .19f, .39f)

        statView = tv("", 1.0f, gravity = Gravity.CENTER)
        dk(statView, 1.4f)
        s.add(statView, .106f, .72f, .19f, .085f)

        charView = ImageView(this)
        charView.setImageResource(R.drawable.char_yuki)
        charView.scaleType = ImageView.ScaleType.FIT_CENTER
        charView.setOnClickListener { onChar() }
        s.add(charView, .3575f, .105f, .285f, .72f)

        bubbleBox = FrameLayout(this)
        val bi = ImageView(this)
        bi.setImageResource(R.drawable.bubble)
        bi.scaleType = ImageView.ScaleType.FIT_XY
        bubbleBox.addView(bi, FrameLayout.LayoutParams(-1, -1))
        bubbleText = tv("", 1.05f, bold = true)
        bubbleBox.addView(bubbleText, FrameLayout.LayoutParams(-1, -1))
        bubbleBox.visibility = View.GONE
        s.add(bubbleBox, .50f, .115f, .175f, .15f)

        // pil nama (ketuk untuk ubah)
        val who = LinearLayout(this)
        who.orientation = LinearLayout.HORIZONTAL
        who.gravity = Gravity.CENTER_VERTICAL
        dk(who, 3f)
        avatar = logoView(0.5f)
        nameView = tv(prefs.getString("name", "Expyy") ?: "Expyy", 1.5f, bold = true)
        who.addView(avatar)
        who.addView(nameView)
        who.setOnClickListener { renameDialog() }
        s.add(who, .81f, .115f, .12f, .06f)

        hiView = tv("Hi everyone", 2f, bold = true)
        s.add(hiView, .68f, .235f, .2f, .06f)

        s.add(card(R.drawable.c3), .68f, .31f, .116f, .345f)
        s.add(card(R.drawable.c1), .809f, .31f, .111f, .167f)
        s.add(card(R.drawable.c2), .809f, .488f, .111f, .167f)

        // kartu musik
        val mus = Pct(this, false)
        gl(mus, 1.4f)
        val cover = logoView(0.18f)
        mus.add(cover, .03f, .13f, .184f, .74f)
        songTitle = tv("", 1.3f, bold = true)
        songTitle.maxLines = 1
        songTitle.ellipsize = TextUtils.TruncateAt.END
        mus.add(songTitle, .24f, .03f, .72f, .30f)
        bar = BarView(this)
        bar.onSeek = { f -> seekTo(f) }
        mus.add(bar, .24f, .36f, .70f, .18f)
        val defs = listOf("↺", "⏮", "▶", "⏭", "＋")
        for (i in defs.indices) {
            val b = tv(defs[i], 1.3f, gravity = Gravity.CENTER)
            gl(b, 5f)
            if (i == 2) playBtn = b
            b.setOnClickListener { musicBtn(i, b) }
            mus.add(b, .24f + i * .125f, .60f, .1f, .34f)
        }
        s.add(mus, .68f, .67f, .24f, .106f)

        // kredit developer
        val dev = LinearLayout(this)
        dev.orientation = LinearLayout.HORIZONTAL
        dev.gravity = Gravity.CENTER_VERTICAL
        dk(dev, 2f)
        tkIcon = ImageView(this)
        tkIcon.setImageResource(R.drawable.ic_tiktok)
        val black = GradientDrawable()
        black.shape = GradientDrawable.OVAL
        black.setColor(Color.BLACK)
        tkIcon.background = black
        dev.addView(tkIcon)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv("DEVELOPER", 0.8f))
        col.addView(tv("HAMXZZ", 1.25f, bold = true))
        val acc = tv("@hamxzz_bejirr", 0.95f)
        acc.setTextColor(0xFF9FE7FF.toInt())
        col.addView(acc)
        dev.addView(col)
        dev.setOnClickListener { openTikTok() }
        s.add(dev, .84f, .895f, .14f, .075f)

        // dock
        dock = LinearLayout(this)
        dock.orientation = LinearLayout.HORIZONTAL
        dock.gravity = Gravity.CENTER
        gl(dock, 2.4f)
        val logo = logoView(0.25f)
        logo.setOnClickListener { Toast.makeText(this, "Kamu sedang di Blue Turbo", Toast.LENGTH_SHORT).show() }
        dock.addView(logo)
        for (g in games) {
            val t = tv(g.first, 1.4f, bold = true, gravity = Gravity.CENTER)
            gl(t, 1.2f)
            t.setOnClickListener { launchFrom(g.second, g.third) }
            dock.addView(t)
        }
        s.add(dock, .351f, .87f, .298f, .1f)
    }

    private fun applyStage(sw: Float) {
        val u = sw / 100f
        for (p in sized) p.first.setTextSize(TypedValue.COMPLEX_UNIT_PX, u * p.second)
        for (p in glassList) p.first.background = Ui.glass(u * p.second)
        for (p in darkList) p.first.background = Ui.dark(u * p.second)
        hiView.paint.shader = LinearGradient(
            0f, 0f, u * 14f, 0f,
            intArrayOf(0xFF0B2A7A.toInt(), 0xFF2457D6.toInt(), 0xFF6A4BD6.toInt()), null, Shader.TileMode.CLAMP
        )
        hiView.invalidate()
        bubbleText.setPadding((u * 2.6f).toInt(), (u * 0.5f).toInt(), (u * 1.6f).toInt(), (u * 1.5f).toInt())
        val av = LinearLayout.LayoutParams((u * 3f).toInt(), (u * 3f).toInt())
        av.marginStart = (u * 0.5f).toInt()
        av.marginEnd = (u * 0.8f).toInt()
        avatar.layoutParams = av
        val tk = LinearLayout.LayoutParams((u * 3f).toInt(), (u * 3f).toInt())
        tk.marginStart = (u * 0.9f).toInt()
        tk.marginEnd = (u * 1f).toInt()
        tkIcon.layoutParams = tk
        tkIcon.setPadding((u * 0.7f).toInt(), (u * 0.7f).toInt(), (u * 0.7f).toInt(), (u * 0.7f).toInt())
        for (i in 0 until dock.childCount) {
            val lp = LinearLayout.LayoutParams((u * 4.2f).toInt(), (u * 4.2f).toInt())
            lp.marginStart = (u * 0.7f).toInt()
            lp.marginEnd = (u * 0.7f).toInt()
            dock.getChildAt(i).layoutParams = lp
        }
    }

    // ---------- karakter: jeli + obrolan ----------
    private fun jelly(v: View) {
        v.pivotX = v.width / 2f
        v.pivotY = v.height.toFloat()
        val sx = PropertyValuesHolder.ofKeyframe(
            View.SCALE_X,
            Keyframe.ofFloat(0f, 1f), Keyframe.ofFloat(.2f, .88f), Keyframe.ofFloat(.4f, 1.09f),
            Keyframe.ofFloat(.6f, .96f), Keyframe.ofFloat(.78f, 1.02f), Keyframe.ofFloat(1f, 1f)
        )
        val sy = PropertyValuesHolder.ofKeyframe(
            View.SCALE_Y,
            Keyframe.ofFloat(0f, 1f), Keyframe.ofFloat(.2f, 1.12f), Keyframe.ofFloat(.4f, .91f),
            Keyframe.ofFloat(.6f, 1.05f), Keyframe.ofFloat(.78f, .98f), Keyframe.ofFloat(1f, 1f)
        )
        val a = ObjectAnimator.ofPropertyValuesHolder(v, sx, sy)
        a.duration = 800
        a.start()
    }

    private fun onChar() {
        if (jellyOn) jelly(charView)
        if (!chatOn) return
        val t = lines[chatIdx % lines.size]
        chatIdx++
        bubbleBox.visibility = View.VISIBLE
        typeRun?.let { h.removeCallbacks(it) }
        hideRun?.let { h.removeCallbacks(it) }
        val total = t.codePointCount(0, t.length)
        var n = 0
        val r = object : Runnable {
            override fun run() {
                n++
                bubbleText.text = t.substring(0, t.offsetByCodePoints(0, minOf(n, total)))
                if (n < total) h.postDelayed(this, 28)
            }
        }
        typeRun = r
        h.post(r)
        val hr = Runnable { bubbleBox.visibility = View.GONE }
        hideRun = hr
        h.postDelayed(hr, 6500)
    }

    // ---------- status HP (data asli) ----------
    private val statRun = object : Runnable {
        override fun run() {
            val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val pct = if (lvl >= 0 && scale > 0) lvl * 100 / scale else 0
            val temp = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
            val mi = ActivityManager.MemoryInfo()
            (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
            val gb = Math.round(mi.totalMem / 1073741824.0)
            statView.text = "Baterai $pct%   Suhu ${"%.0f".format(temp)}°C\nRAM $gb GB   Core ${Runtime.getRuntime().availableProcessors()}"
            h.postDelayed(this, 10000)
        }
    }

    // ---------- musik ----------
    private fun initMusic() {
        names.add("Lagu pilihanmu")
        uris.add(null)
        val raw = prefs.getString("songs", "") ?: ""
        for (line in raw.split("\n")) {
            if (line.isBlank()) continue
            val p = line.split("\u0001")
            if (p.size == 2) {
                names.add(p[0])
                uris.add(Uri.parse(p[1]))
            }
        }
        loadTrack(0, false)
        h.post(tickRun)
    }

    private val tickRun = object : Runnable {
        override fun run() {
            val m = mp
            if (m != null) {
                val d = m.duration
                bar.progress = if (d > 0) m.currentPosition.toFloat() / d else 0f
                bar.invalidate()
            }
            h.postDelayed(this, 500)
        }
    }

    private fun loadTrack(i: Int, play: Boolean) {
        mp?.release()
        mp = null
        cur = ((i % names.size) + names.size) % names.size
        songTitle.text = names[cur]
        try {
            val u = uris[cur]
            val m: MediaPlayer? = if (u == null) {
                MediaPlayer.create(this, R.raw.song1)
            } else {
                val x = MediaPlayer()
                x.setDataSource(this, u)
                x.prepare()
                x
            }
            if (m == null) {
                Toast.makeText(this, "Lagu tidak bisa diputar", Toast.LENGTH_SHORT).show()
                return
            }
            m.setOnCompletionListener {
                if (rep) loadTrack(cur, true) else loadTrack(cur + 1, true)
            }
            mp = m
            if (play) {
                m.start()
                playBtn.text = "❚❚"
            } else {
                playBtn.text = "▶"
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Lagu tidak bisa diputar", Toast.LENGTH_SHORT).show()
        }
    }

    private fun musicBtn(i: Int, b: TextView) {
        when (i) {
            0 -> {
                rep = !rep
                b.setTextColor(if (rep) 0xFF46D9FF.toInt() else Color.WHITE)
                Toast.makeText(this, if (rep) "Ulangi lagu: aktif" else "Lanjut otomatis ke lagu berikutnya", Toast.LENGTH_SHORT).show()
            }
            1 -> loadTrack(cur - 1, mp?.isPlaying == true)
            2 -> {
                val m = mp
                if (m != null) {
                    if (m.isPlaying) {
                        m.pause()
                        playBtn.text = "▶"
                    } else {
                        m.start()
                        playBtn.text = "❚❚"
                    }
                }
            }
            3 -> loadTrack(cur + 1, mp?.isPlaying == true)
            else -> pickSongs()
        }
    }

    private fun seekTo(f: Float) {
        val m = mp ?: return
        m.seekTo((m.duration * f).toInt())
    }

    private fun pickSongs() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "audio/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(i, 77)
    }

    private fun nameOf(u: Uri): String {
        var n = "Lagu"
        try {
            contentResolver.query(u, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) n = c.getString(i)
            }
        } catch (e: Exception) {
        }
        return n.replace(Regex("\\.[^.]+$"), "")
    }

    private fun saveSongs() {
        val sb = StringBuilder()
        for (i in 1 until names.size) {
            sb.append(names[i]).append('\u0001').append(uris[i].toString()).append('\n')
        }
        prefs.edit().putString("songs", sb.toString()).apply()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 77 || resultCode != RESULT_OK || data == null) return
        val list = ArrayList<Uri>()
        val cd = data.clipData
        if (cd != null) {
            for (k in 0 until cd.itemCount) list.add(cd.getItemAt(k).uri)
        } else {
            val one = data.data
            if (one != null) list.add(one)
        }
        var first = -1
        for (u in list) {
            try {
                contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
            }
            names.add(nameOf(u))
            uris.add(u)
            if (first < 0) first = names.size - 1
        }
        saveSongs()
        if (first >= 0) {
            loadTrack(first, true)
            Toast.makeText(this, "${list.size} lagu ditambahkan", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- menu kiri ----------
    private fun sideClick(i: Int) {
        when (i) {
            0 -> libDialog()
            1, 3 -> appsDialog()
            2 -> playlistDialog()
            4 -> focusDialog()
            5 -> settingsDialog()
            6 -> aboutDialog()
            else -> {
                val on = !snow.enabledSnow
                snow.enabledSnow = on
                prefs.edit().putBoolean("snow", on).apply()
                Toast.makeText(this, if (on) "Salju menyala" else "Salju dimatikan", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------- Perpustakaan Game (maks. 10) ----------
    private fun libPkgs(): MutableList<String> {
        val raw = prefs.getString("lib", "") ?: ""
        return raw.split("\n").filter { it.isNotBlank() }.toMutableList()
    }

    private fun saveLib(l: List<String>) {
        prefs.edit().putString("lib", l.joinToString("\n")).apply()
    }

    private fun appLabel(pkg: String): String {
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    private fun libDialog() {
        val dlg = Dialog(this, android.R.style.Theme_Material_Dialog_NoActionBar)
        val list = libPkgs()
        val u = resources.displayMetrics.density
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding((22 * u).toInt(), (18 * u).toInt(), (22 * u).toInt(), (20 * u).toInt())
        root.background = Ui.dark(20 * u)

        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "Perpustakaan Game   ${list.size} / 10"
        title.setTextColor(Color.WHITE)
        title.textSize = 16f
        title.typeface = Typeface.DEFAULT_BOLD
        head.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val addTop = TextView(this)
        addTop.text = "Tambah ＋"
        addTop.setTextColor(Color.WHITE)
        addTop.textSize = 13f
        addTop.setPadding((16 * u).toInt(), (8 * u).toInt(), (16 * u).toInt(), (8 * u).toInt())
        addTop.background = Ui.glass(20 * u)
        addTop.setOnClickListener { pickGameToAdd(dlg, list) }
        head.addView(addTop)
        root.addView(head)

        if (list.isEmpty()) {
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.gravity = Gravity.CENTER_HORIZONTAL
            card.setPadding((16 * u).toInt(), (18 * u).toInt(), (16 * u).toInt(), (14 * u).toInt())
            card.background = Ui.glass(16 * u)
            val ic = TextView(this)
            ic.text = "🎮"
            ic.textSize = 26f
            ic.gravity = Gravity.CENTER
            card.addView(ic)
            val t1 = TextView(this)
            t1.text = "Belum ada game"
            t1.setTextColor(Color.WHITE)
            t1.textSize = 16f
            t1.typeface = Typeface.DEFAULT_BOLD
            t1.gravity = Gravity.CENTER
            card.addView(t1)
            val t2 = TextView(this)
            t2.text = "Tambahkan game favoritmu supaya Blue Turbo bisa mengoptimalkannya."
            t2.setTextColor(0xFFA9C3E6.toInt())
            t2.textSize = 12f
            t2.gravity = Gravity.CENTER
            t2.setPadding(0, (6 * u).toInt(), 0, 0)
            card.addView(t2)
            val clp = LinearLayout.LayoutParams(-1, -2)
            clp.topMargin = (14 * u).toInt()
            root.addView(card, clp)
        } else {
            val sv = ScrollView(this)
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            for (pkg in list) {
                val row = LinearLayout(this)
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding((8 * u).toInt(), (8 * u).toInt(), (8 * u).toInt(), (8 * u).toInt())
                row.background = Ui.glass(12 * u)
                val ico = ImageView(this)
                try {
                    ico.setImageDrawable(packageManager.getApplicationIcon(pkg))
                } catch (e: Exception) {
                }
                row.addView(ico, LinearLayout.LayoutParams((40 * u).toInt(), (40 * u).toInt()))
                val tvName = TextView(this)
                tvName.text = appLabel(pkg)
                tvName.setTextColor(Color.WHITE)
                tvName.textSize = 14f
                tvName.setPadding((12 * u).toInt(), 0, 0, 0)
                row.addView(tvName, LinearLayout.LayoutParams(0, -2, 1f))
                val rm = TextView(this)
                rm.text = "✕"
                rm.setTextColor(0xFFFF8FA3.toInt())
                rm.textSize = 16f
                rm.setPadding((14 * u).toInt(), (6 * u).toInt(), (6 * u).toInt(), (6 * u).toInt())
                rm.setOnClickListener {
                    list.remove(pkg)
                    saveLib(list)
                    dlg.dismiss()
                    libDialog()
                }
                row.addView(rm)
                row.setOnClickListener {
                    dlg.dismiss()
                    launchGame(pkg)
                }
                val rlp = LinearLayout.LayoutParams(-1, -2)
                rlp.topMargin = (8 * u).toInt()
                col.addView(row, rlp)
            }
            sv.addView(col)
            val slp = LinearLayout.LayoutParams(-1, (190 * u).toInt())
            slp.topMargin = (6 * u).toInt()
            root.addView(sv, slp)
        }

        val big = TextView(this)
        big.text = "＋  Tambah Game"
        big.setTextColor(0xFF04223E.toInt())
        big.textSize = 15f
        big.typeface = Typeface.DEFAULT_BOLD
        big.gravity = Gravity.CENTER
        big.setPadding((30 * u).toInt(), (12 * u).toInt(), (30 * u).toInt(), (12 * u).toInt())
        val gd = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF9FE7FF.toInt(), 0xFF6AB8FF.toInt()))
        gd.cornerRadius = 30 * u
        big.background = gd
        big.setOnClickListener { pickGameToAdd(dlg, list) }
        val blp = LinearLayout.LayoutParams(-2, -2)
        blp.gravity = Gravity.CENTER_HORIZONTAL
        blp.topMargin = (16 * u).toInt()
        root.addView(big, blp)

        dlg.setContentView(root)
        dlg.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dlg.show()
        dlg.window?.setLayout((resources.displayMetrics.widthPixels * 0.55f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun pickGameToAdd(dlg: Dialog, list: MutableList<String>, all: Boolean = false) {
        if (list.size >= 10) {
            Toast.makeText(this, "Maksimal 10 game", Toast.LENGTH_SHORT).show()
            return
        }
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != packageName && !list.contains(it.activityInfo.packageName) }
            .filter { all || isGame(it) }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        if (apps.isEmpty() && !all) {
            pickGameToAdd(dlg, list, true)
            return
        }
        val labels = apps.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        val b = AlertDialog.Builder(this)
            .setTitle(if (all) "Semua aplikasi di HP" else "Game di HP kamu")
            .setItems(labels) { _, w ->
                list.add(apps[w].activityInfo.packageName)
                saveLib(list)
                dlg.dismiss()
                libDialog()
            }
        if (!all) b.setNeutralButton("Semua aplikasi") { _, _ -> pickGameToAdd(dlg, list, true) }
        b.show()
    }

    @Suppress("DEPRECATION")
    private fun isGame(r: ResolveInfo): Boolean {
        val ai = r.activityInfo.applicationInfo
        return ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
    }

    private fun appsDialog() {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        val labels = apps.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Pilih game / aplikasi")
            .setItems(labels) { _, w -> launchGame(apps[w].activityInfo.packageName) }
            .show()
    }

    private fun playlistDialog() {
        AlertDialog.Builder(this)
            .setTitle("Playlist")
            .setItems(names.toTypedArray()) { _, w -> loadTrack(w, true) }
            .setPositiveButton("＋ Tambah lagu") { _, _ -> pickSongs() }
            .show()
    }

    private fun focusDialog() {
        AlertDialog.Builder(this)
            .setTitle("Mode fokus")
            .setMessage("Tombol Jangan Ganggu dan Anti Call ada di panel turbo saat bermain. Keduanya butuh izin Akses Jangan Ganggu.")
            .setPositiveButton("Buka izin") { _, _ ->
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun settingsDialog() {
        val items = arrayOf("Salju saat diketuk", "Goyang jeli", "Obrolan Yuki")
        val checked = booleanArrayOf(snow.enabledSnow, jellyOn, chatOn)
        AlertDialog.Builder(this)
            .setTitle("Pengaturan")
            .setMultiChoiceItems(items, checked) { _, which, isChecked ->
                when (which) {
                    0 -> snow.enabledSnow = isChecked
                    1 -> jellyOn = isChecked
                    else -> chatOn = isChecked
                }
                prefs.edit().putBoolean("snow", snow.enabledSnow).putBoolean("jelly", jellyOn).putBoolean("chat", chatOn).apply()
            }
            .setPositiveButton("Selesai", null)
            .show()
    }

    private fun aboutDialog() {
        AlertDialog.Builder(this)
            .setTitle("Blue Turbo v2.0")
            .setMessage("Developer: HAMXZZ\nTikTok: @hamxzz_bejirr")
            .setPositiveButton("Buka TikTok") { _, _ -> openTikTok() }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun renameDialog() {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_TEXT
        et.setText(nameView.text)
        et.setSelection(et.text.length)
        AlertDialog.Builder(this)
            .setTitle("Ubah nama")
            .setView(et)
            .setPositiveButton("Simpan") { _, _ ->
                val v = et.text.toString().trim().take(14)
                if (v.isNotEmpty()) {
                    nameView.text = v
                    prefs.edit().putString("name", v).apply()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun openTikTok() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tiktok.com/@hamxzz_bejirr")))
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak bisa membuka TikTok", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- buka game + panel turbo ----------
    private fun launchFrom(name: String, pkgs: List<String>) {
        val pkg = pkgs.firstOrNull { packageManager.getLaunchIntentForPackage(it) != null }
        if (pkg == null) {
            Toast.makeText(this, "$name belum terpasang", Toast.LENGTH_SHORT).show()
            return
        }
        launchGame(pkg)
    }

    private fun launchGame(pkg: String) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Aktifkan izin \"Tampil di atas aplikasi lain\", lalu pilih game lagi", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val li = packageManager.getLaunchIntentForPackage(pkg)
        if (li == null) {
            Toast.makeText(this, "Aplikasi tidak bisa dibuka", Toast.LENGTH_SHORT).show()
            return
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        startActivity(li)
    }
}
