package com.example.gameturbo

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Tata letak berbasis persen. fit=true: kotak 16:9 di tengah layar. */
class Pct(ctx: Context, private val fit: Boolean) : ViewGroup(ctx) {
    class LP(val x: Float, val y: Float, val w: Float, val h: Float) : ViewGroup.LayoutParams(0, 0)

    private var sw = 0f
    private var sh = 0f
    private var ox = 0f
    private var oy = 0f
    var onStage: ((Float) -> Unit)? = null

    override fun checkLayoutParams(p: ViewGroup.LayoutParams?): Boolean = p is LP

    override fun onMeasure(ws: Int, hs: Int) {
        val fw = MeasureSpec.getSize(ws).toFloat()
        val fh = MeasureSpec.getSize(hs).toFloat()
        setMeasuredDimension(fw.toInt(), fh.toInt())
        val nsw = if (fit) minOf(fw, fh * 16f / 9f) else fw
        val nsh = if (fit) nsw * 9f / 16f else fh
        if (nsw != sw) {
            sw = nsw
            onStage?.invoke(sw)
        }
        sh = nsh
        ox = (fw - sw) / 2f
        oy = (fh - sh) / 2f
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val lp = c.layoutParams as LP
            c.measure(
                MeasureSpec.makeMeasureSpec((lp.w * sw).toInt(), MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec((lp.h * sh).toInt(), MeasureSpec.EXACTLY)
            )
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val lp = c.layoutParams as LP
            val x = (ox + lp.x * sw).toInt()
            val y = (oy + lp.y * sh).toInt()
            c.layout(x, y, x + c.measuredWidth, y + c.measuredHeight)
        }
    }

    fun add(v: View, x: Float, y: Float, w: Float, h: Float) {
        addView(v, LP(x, y, w, h))
    }
}

/** Kalender bulan ini dengan tanggal hari ini disorot. */
class CalView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.shader = LinearGradient(0f, 0f, w, h, 0xFF0B1A4A.toInt(), 0xFF2D2184.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(0f, 0f, w, h, w * 0.08f, w * 0.08f, p)
        p.shader = null

        val cal = Calendar.getInstance()
        val today = cal.get(Calendar.DAY_OF_MONTH)
        val month = SimpleDateFormat("MMMM", Locale("id")).format(cal.time)
        p.textAlign = Paint.Align.CENTER
        p.isFakeBoldText = true
        p.color = Color.WHITE
        p.textSize = w * 0.075f
        c.drawText(month.replaceFirstChar { it.uppercase() }, w / 2f, h * 0.10f, p)
        p.color = 0x55FFFFFF
        c.drawRect(w * 0.07f, h * 0.125f, w * 0.93f, h * 0.13f, p)

        val letters = "MSSRKJS"
        val cell = w * 0.86f / 7f
        val x0 = w * 0.07f
        p.textSize = w * 0.058f
        p.isFakeBoldText = false
        p.color = 0xFFA9C3E6.toInt()
        for (i in 0 until 7) c.drawText(letters[i].toString(), x0 + cell * (i + 0.5f), h * 0.20f, p)

        val first = Calendar.getInstance()
        first.set(Calendar.DAY_OF_MONTH, 1)
        val offset = first.get(Calendar.DAY_OF_WEEK) - 1
        val total = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        for (d in 1..total) {
            val idx = offset + d - 1
            val cx = x0 + cell * ((idx % 7) + 0.5f)
            val cy = h * 0.30f + (idx / 7) * h * 0.108f
            if (d == today) {
                p.shader = LinearGradient(cx - cell / 2, cy, cx + cell / 2, cy, 0xFF46D9FF.toInt(), 0xFF7A6BFF.toInt(), Shader.TileMode.CLAMP)
                c.drawRoundRect(cx - cell * 0.42f, cy - h * 0.045f, cx + cell * 0.42f, cy + h * 0.045f, cell * 0.25f, cell * 0.25f, p)
                p.shader = null
                p.color = 0xFF04122E.toInt()
                p.isFakeBoldText = true
            } else {
                p.color = Color.WHITE
                p.isFakeBoldText = false
            }
            c.drawText(d.toString(), cx, cy + w * 0.02f, p)
        }
    }
}

/** Bar progres lagu; ketuk untuk geser posisi. */
class BarView(ctx: Context) : View(ctx) {
    var progress = 0f
    var onSeek: ((Float) -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 4f
        p.shader = null
        p.color = 0x55FFFFFF
        c.drawRoundRect(0f, h * 0.25f, w, h * 0.75f, r, r, p)
        p.shader = LinearGradient(0f, 0f, w, 0f, 0xFF46D9FF.toInt(), 0xFF7A6BFF.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(0f, h * 0.25f, w * progress.coerceIn(0f, 1f), h * 0.75f, r, r, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN) return true
        if (e.action == MotionEvent.ACTION_UP) {
            onSeek?.invoke((e.x / width).coerceIn(0f, 1f))
            return true
        }
        return super.onTouchEvent(e)
    }
}

/** Percikan salju di titik ketukan. */
class SnowView(ctx: Context) : View(ctx) {
    private class Pt(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val r: Float)

    private val pts = ArrayList<Pt>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    var enabledSnow = true

    fun burst(x: Float, y: Float) {
        if (!enabledSnow || pts.size > 100) return
        val d = resources.displayMetrics.density
        for (i in 0 until 9) {
            val a = Math.random() * 6.283
            val s = (40 + Math.random() * 160) * d
            pts.add(Pt(x, y, (Math.cos(a) * s).toFloat(), (Math.sin(a) * s).toFloat() - 20 * d, 1f, ((1.5 + Math.random() * 3) * d).toFloat()))
        }
        postInvalidateOnAnimation()
    }

    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val dt = 0.016f
        val it = pts.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.vy += 60 * d * dt
            p.vx *= 0.985f
            p.life -= dt * 1.1f
            if (p.life <= 0f) {
                it.remove()
                continue
            }
            paint.color = Color.WHITE
            paint.alpha = (p.life * 255).toInt().coerceIn(0, 255)
            c.drawCircle(p.x, p.y, p.r, paint)
        }
        if (pts.isNotEmpty()) postInvalidateOnAnimation()
    }
}

/** Crosshair dengan beberapa bentuk. */
class XhView(ctx: Context) : View(ctx) {
    var color = 0xFFFF2D3D.toInt()
    var shape = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val s = w / 100f
        val cx = w / 2f
        val cy = height / 2f
        p.color = color
        p.strokeCap = Paint.Cap.ROUND
        p.style = Paint.Style.STROKE
        p.strokeWidth = 5f * s
        when (shape) {
            0 -> {
                c.drawLine(cx, 8f * s, cx, 40f * s, p)
                c.drawLine(cx, 60f * s, cx, 92f * s, p)
                c.drawLine(8f * s, cy, 40f * s, cy, p)
                c.drawLine(60f * s, cy, 92f * s, cy, p)
            }
            1 -> {
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, 7f * s, p)
            }
            2 -> {
                c.drawCircle(cx, cy, 24f * s, p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, 3.5f * s, p)
            }
            3 -> {
                p.strokeWidth = 4f * s
                c.drawCircle(cx, cy, 17f * s, p)
                c.drawLine(cx, 4f * s, cx, 30f * s, p)
                c.drawLine(cx, 70f * s, cx, 96f * s, p)
                c.drawLine(4f * s, cy, 30f * s, cy, p)
                c.drawLine(70f * s, cy, 96f * s, cy, p)
            }
            else -> {
                c.drawLine(26f * s, 26f * s, 44f * s, 44f * s, p)
                c.drawLine(56f * s, 56f * s, 74f * s, 74f * s, p)
                c.drawLine(74f * s, 26f * s, 56f * s, 44f * s, p)
                c.drawLine(44f * s, 56f * s, 26f * s, 74f * s, p)
            }
        }
    }
}
