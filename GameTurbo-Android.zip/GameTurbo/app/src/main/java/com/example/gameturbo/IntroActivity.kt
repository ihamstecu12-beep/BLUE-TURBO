package com.example.gameturbo

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.VideoView

/** Intro: hanya video + tombol Skip. */
class IntroActivity : Activity() {
    private var done = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.immersive(window)
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        val vv = VideoView(this)
        root.addView(vv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))

        val skip = TextView(this)
        skip.text = "Skip ›"
        skip.setTextColor(Color.WHITE)
        skip.textSize = 15f
        skip.typeface = Typeface.DEFAULT_BOLD
        skip.gravity = Gravity.CENTER
        skip.setPadding(dp(22), dp(10), dp(22), dp(10))
        skip.background = Ui.glass(dp(30).toFloat())
        skip.setOnClickListener { finishIntro() }
        val lp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END)
        lp.setMargins(0, dp(16), dp(28), 0)
        root.addView(skip, lp)
        setContentView(root)

        vv.setVideoURI(Uri.parse("android.resource://" + packageName + "/" + R.raw.intro))
        vv.setOnCompletionListener { finishIntro() }
        vv.setOnErrorListener { _, _, _ -> finishIntro(); true }
        vv.start()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun finishIntro() {
        if (done) return
        done = true
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
