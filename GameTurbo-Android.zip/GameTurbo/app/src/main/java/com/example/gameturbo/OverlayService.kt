package com.example.gameturbo

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.BatteryManager
import android.os.IBinder
import android.provider.Settings
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

/** Panel turbo mengambang di atas game. */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager
    private lateinit var nm: NotificationManager
    private lateinit var prefs: SharedPreferences
    private lateinit var gauge: TextView
    private val d by lazy { resources.displayMetrics.density }

    private var panel: View? = null
    private var strip: View? = null
    private var dim: View? = null
    private var xh: XhView? = null
    private var bubble: View? = null

    private var muted = false
    private var dimLevel = 0
    private var cool = false
    private var dndOn = false
    private var callOn = false
    private var xhOn = false
    private var origFilter = -1
    private val dimAlpha = intArrayOf(0, 90, 165)

    private var frames = 0
    private var lastNs = 0L
    private var running = false
    private var lastWarn = 0L

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, buildNotification())
        if (panel == null) {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            audio = getSystemService(AUDIO_SERVICE) as AudioManager
            nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            prefs = getSharedPreferences("bt", MODE_PRIVATE)
            addDim()
            addCrosshair()
            addPanel()
            addStrip()
            addBubble()
            running = true
            Choreographer.getInstance().postFrameCallback(frameCb)
        }
        return START_STICKY
    }

    private fun overlayParams(w: Int, h: Int, touchable: Boolean): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
            PixelFormat.TRANSLUCENT
        )

    private fun toast(t: String) {
        Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    }

    private fun px(v: Float): Int = (v * d).toInt()

    // ---------- peredup layar + crosshair ----------
    private fun addDim() {
        val v = View(this)
        v.setBackgroundColor(Color.argb(0, 0, 0, 0))
        dim = v
        wm.addView(v, overlayParams(-1, -1, false))
    }

    private fun updateDim() {
        val a = maxOf(dimAlpha[dimLevel], if (cool) 140 else 0)
        dim?.setBackgroundColor(Color.argb(a, 0, 0, 0))
    }

    private fun addCrosshair() {
        val v = XhView(this)
        v.color = prefs.getInt("xc", 0xFFFF2D3D.toInt())
        v.shape = prefs.getInt("xs", 0)
        v.visibility = View.GONE
        xh = v
        val sz = px(prefs.getInt("xz", 44).toFloat())
        val lp = overlayParams(sz, sz, false)
        lp.gravity = Gravity.CENTER
        wm.addView(v, lp)
    }

    private fun xhResize(dp: Int) {
        val v = xh ?: return
        val lp = v.layoutParams as WindowManager.LayoutParams
        lp.width = px(dp.toFloat())
        lp.height = lp.width
        wm.updateViewLayout(v, lp)
    }

    private fun updateStrip() {
        strip?.visibility = if (xhOn && panel?.visibility == View.VISIBLE) View.VISIBLE else View.GONE
    }

    // ---------- jangan ganggu / anti call ----------
    private fun hasPolicy(): Boolean {
        if (nm.isNotificationPolicyAccessGranted) return true
        toast("Beri izin Akses Jangan Ganggu dulu")
        val i = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        return false
    }

    private fun applyFilter() {
        if (origFilter < 0) origFilter = nm.currentInterruptionFilter
        nm.setInterruptionFilter(
            if (callOn) NotificationManager.INTERRUPTION_FILTER_ALARMS
            else if (dndOn) NotificationManager.INTERRUPTION_FILTER_PRIORITY
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
    }

    // ---------- suhu ----------
    private fun battTemp(): Float {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    }

    // ---------- panel ----------
    private fun addPanel() {
        val bAudio = HexButton(this, "♪", "Audio")
        bAudio.active = true
        val bBright = HexButton(this, "☀", "Cerah")
        val bCross = HexButton(this, "⊕", "Crosshair")
        val bDnd = HexButton(this, "☾", "Jangan\nGanggu")
        val bCall = HexButton(this, "✆", "Anti\nCall")
        val bCool = HexButton(this, "❄", "Mode\nDingin")
        val hz60 = HexButton(this, "60", "Hz")
        hz60.active = true
        val hz90 = HexButton(this, "", "90 Hz")
        hz90.locked = true
        val hz120 = HexButton(this, "", "120 Hz")
        hz120.locked = true

        bAudio.setOnClickListener {
            muted = !muted
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (muted) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE, 0)
            bAudio.active = !muted
        }
        bBright.setOnClickListener {
            dimLevel = (dimLevel + 1) % dimAlpha.size
            updateDim()
            bBright.active = dimLevel > 0
        }
        bCross.setOnClickListener {
            xhOn = !xhOn
            xh?.visibility = if (xhOn) View.VISIBLE else View.GONE
            bCross.active = xhOn
            updateStrip()
        }
        bDnd.setOnClickListener {
            if (hasPolicy()) {
                dndOn = !dndOn
                bDnd.active = dndOn
                applyFilter()
                toast(if (dndOn) "Jangan Ganggu aktif" else "Jangan Ganggu mati")
            }
        }
        bCall.setOnClickListener {
            if (hasPolicy()) {
                callOn = !callOn
                bCall.active = callOn
                applyFilter()
                toast(if (callOn) "Anti Call aktif: telepon masuk disenyapkan" else "Anti Call mati")
            }
        }
        bCool.setOnClickListener {
            cool = !cool
            bCool.active = cool
            updateDim()
            toast(if (cool) "Mode Dingin aktif: layar diredupkan. Suhu baterai ${"%.0f".format(battTemp())}°C" else "Mode Dingin mati")
        }
        val locked = View.OnClickListener { toast("Layar ini tidak mendukung Hz tersebut") }
        hz90.setOnClickListener(locked)
        hz120.setOnClickListener(locked)

        gauge = TextView(this)
        gauge.setTextColor(Color.WHITE)
        gauge.textSize = 14f
        gauge.typeface = Typeface.DEFAULT_BOLD
        gauge.gravity = Gravity.CENTER
        gauge.text = "LAYAR\n--\n--"

        val close = TextView(this)
        close.text = "✕"
        close.textSize = 16f
        close.setTextColor(Color.WHITE)
        close.gravity = Gravity.CENTER
        val red = GradientDrawable()
        red.shape = GradientDrawable.OVAL
        red.setColor(0xCCE0243F.toInt())
        red.setStroke(px(1.5f), 0xB0FFFFFF.toInt())
        close.background = red
        close.setOnClickListener { collapse() }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(px(12f), px(8f), px(12f), px(8f))
        row.background = Ui.dark(18f * d)
        val items = listOf<View>(bAudio, bBright, bCross, bDnd, bCall, bCool)
        for (v in items) row.addView(v)
        row.addView(gauge, LinearLayout.LayoutParams(px(70f), -2))
        row.addView(hz60)
        row.addView(hz90)
        row.addView(hz120)
        val clp = LinearLayout.LayoutParams(px(38f), px(38f))
        clp.marginStart = px(6f)
        row.addView(close, clp)
        panel = row

        val lp = overlayParams(-2, -2, true)
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = px(6f)
        wm.addView(row, lp)
    }

    // ---------- pengaturan crosshair: warna, bentuk, ukuran ----------
    private fun addStrip() {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(px(14f), px(6f), px(14f), px(6f))
        row.background = Ui.dark(16f * d)

        val colors = intArrayOf(0xFFFF2D3D.toInt(), 0xFFFFD60A.toInt(), 0xFF2CF07A.toInt(), 0xFF46D9FF.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF4DF0.toInt())
        for (col in colors) {
            val dot = View(this)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(col)
            g.setStroke(px(2f), 0xAAFFFFFF.toInt())
            dot.background = g
            dot.setOnClickListener {
                xh?.color = col
                xh?.invalidate()
                prefs.edit().putInt("xc", col).apply()
            }
            val lp = LinearLayout.LayoutParams(px(22f), px(22f))
            lp.setMargins(px(4f), 0, px(4f), 0)
            row.addView(dot, lp)
        }
        val shapes = listOf("┼", "●", "◎", "⊕", "✕")
        for (i in shapes.indices) {
            val t = TextView(this)
            t.text = shapes[i]
            t.textSize = 16f
            t.setTextColor(Color.WHITE)
            t.gravity = Gravity.CENTER
            t.background = Ui.glass(8f * d)
            t.setOnClickListener {
                xh?.shape = i
                xh?.invalidate()
                prefs.edit().putInt("xs", i).apply()
            }
            val lp = LinearLayout.LayoutParams(px(30f), px(30f))
            lp.setMargins(px(4f), 0, px(4f), 0)
            row.addView(t, lp)
        }
        val sb = SeekBar(this)
        sb.max = 60
        sb.progress = prefs.getInt("xz", 44) - 24
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val dp = 24 + p
                prefs.edit().putInt("xz", dp).apply()
                xhResize(dp)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        row.addView(sb, LinearLayout.LayoutParams(px(130f), -2))
        row.visibility = View.GONE
        strip = row

        val lp = overlayParams(-2, -2, true)
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = px(112f)
        wm.addView(row, lp)
    }

    // ---------- logo kecil: ketuk = buka panel, geser = pindah, tahan = tutup ----------
    private fun addBubble() {
        val size = px(52f)
        val v = ImageView(this)
        v.setImageResource(R.drawable.logo)
        v.scaleType = ImageView.ScaleType.CENTER_CROP
        v.clipToOutline = true
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, o: Outline) {
                o.setOval(0, 0, view.width, view.height)
            }
        }
        v.visibility = View.GONE
        val lp = overlayParams(size, size, true)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = px(12f)
        lp.y = px(12f)
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        var downTime = 0L
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x
                    sy = lp.y
                    tx = e.rawX
                    ty = e.rawY
                    moved = false
                    downTime = e.eventTime
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (Math.abs(dx) > 10 * d || Math.abs(dy) > 10 * d) moved = true
                    if (moved) {
                        lp.x = sx + dx.toInt()
                        lp.y = sy + dy.toInt()
                        wm.updateViewLayout(v, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (e.eventTime - downTime > 700) stopSelf() else expand()
                    }
                }
            }
            true
        }
        bubble = v
        wm.addView(v, lp)
    }

    private fun collapse() {
        panel?.visibility = View.GONE
        bubble?.visibility = View.VISIBLE
        updateStrip()
    }

    private fun expand() {
        bubble?.visibility = View.GONE
        panel?.visibility = View.VISIBLE
        updateStrip()
    }

    // ---------- angka layar + suhu ----------
    // "LAYAR" = laju refresh layar (Choreographer), BUKAN FPS game lain.
    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(ns: Long) {
            if (!running) return
            if (lastNs == 0L) lastNs = ns
            frames++
            if (ns - lastNs >= 1_000_000_000L) {
                val hz = (frames * 1_000_000_000.0 / (ns - lastNs)).toInt()
                val t = battTemp()
                gauge.text = "LAYAR\n$hz\n${"%.0f".format(t)}°C"
                if (t >= 41f && !cool && System.currentTimeMillis() - lastWarn > 60000) {
                    lastWarn = System.currentTimeMillis()
                    toast("HP mulai panas (${"%.0f".format(t)}°C). Coba Mode Dingin")
                }
                frames = 0
                lastNs = ns
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun buildNotification(): Notification {
        val m = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        m.createNotificationChannel(NotificationChannel("turbo", "Blue Turbo", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, "turbo")
            .setContentTitle("Blue Turbo aktif")
            .setContentText("Panel turbo tampil di atas game")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
    }

    override fun onDestroy() {
        running = false
        if (muted) audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
        if (origFilter >= 0 && nm.isNotificationPolicyAccessGranted) nm.setInterruptionFilter(origFilter)
        for (v in listOf(panel, strip, dim, xh, bubble)) {
            if (v != null) {
                try {
                    wm.removeView(v)
                } catch (e: Exception) {
                }
            }
        }
        super.onDestroy()
    }
}
