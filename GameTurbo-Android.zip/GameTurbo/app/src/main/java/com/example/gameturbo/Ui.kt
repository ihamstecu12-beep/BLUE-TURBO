package com.example.gameturbo

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.View
import android.view.Window
import android.view.WindowManager

object Ui {
    /** Kaca bening: gradasi putih transparan + tepi terang. */
    fun glass(radius: Float): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0x55FFFFFF, 0x167AA9FF)).apply {
            cornerRadius = radius
            setStroke(2, 0x70FFFFFF)
        }

    /** Kaca gelap kebiruan untuk kartu yang butuh teks jelas. */
    fun dark(radius: Float): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xD90B1A4A.toInt(), 0xD92D2184.toInt())).apply {
            cornerRadius = radius
            setStroke(2, 0x55A0BEFF)
        }

    fun dp(ctx: Context, v: Float): Float = v * ctx.resources.displayMetrics.density

    fun immersive(w: Window) {
        w.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = w.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            w.attributes = lp
        }
        @Suppress("DEPRECATION")
        w.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }
}
